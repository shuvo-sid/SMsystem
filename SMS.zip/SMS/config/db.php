
    <?php
        define('db_host', '127.0.0.1');
        define('db_user', 'shuvo');
        define('db_pass', '123456');
        define('db_name', 'sms');
    ?>
    