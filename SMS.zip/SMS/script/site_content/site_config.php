<?php


include "script/site_content/form.php";



class site_config extends form{}


?>