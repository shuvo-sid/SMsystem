<?php



class    fun
{
  
  public function test_fun(){
    echo "hello fun";
  }
  
}

?>