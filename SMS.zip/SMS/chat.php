<?php

include "layout/header.php";
include "page/chat/chat.php";
include "layout/footer.php";


?>


